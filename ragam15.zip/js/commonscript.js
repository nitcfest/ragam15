/**********fade white***************/

$(window).load(function() 
{
	$("#fadebox").fadeOut(1000);
	
});
